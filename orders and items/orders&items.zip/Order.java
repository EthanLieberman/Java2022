import java.util.ArrayList;

public class Order{

    private String name;
    private double total;
    private boolean ready;
    private ArrayList<Item> item;


    public Order(String name){
        this.name = name;
        this.total= 0;
        this.ready = false;
        this.item = new ArrayList<Item>();
    }


    public void addItem(Item item){
        this.item.add(item);
        this.total = this.total + item.getPrice();
    }



    //getters and setters

    public String getName(){
        return this.name;
    }

    public void setName(String name){
        this.name = name;
    }


    public double getTotal(){
        return this.total;
    }

    public void setTotal(double value){
        this.total = value;
    }

    public void isReady(){
        if (this.ready){
            System.out.println("Ready");
        }
    }

    public void setReady(){
        this.ready = true;
    }

    public void getItems(){
        for (int i = 0; i < this.item.size(); i++){
            System.out.print(this.item.get(i));
        }
    }


}
